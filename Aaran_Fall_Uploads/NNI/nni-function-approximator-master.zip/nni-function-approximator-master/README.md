# nni-function-approximator

This repository contains code for this post "Neural Architecture Search with NNI":

https://towardsdatascience.com/neural-network-intelligence-to-learn-function-approximation-44046de9cccb?source=friends_link&sk=70135c4db70a2790b53b4bbc9ba55c08
